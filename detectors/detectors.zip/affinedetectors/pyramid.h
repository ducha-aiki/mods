/*
 * Copyright (C) 2008-12 Michal Perdoch
 * All rights reserved.
 *
 * This file is part of the HessianAffine detector and is made available under
 * the terms of the BSD license (see the COPYING file).
 *
 */

#ifndef __PYRAMID_H__
#define __PYRAMID_H__


#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "../helpers.h"
#include "../structures.hpp"
using namespace cv;

bool responseCompare(AffineKeypoint k1,AffineKeypoint k2);
bool responseCompareInvOrder(AffineKeypoint k1,AffineKeypoint k2);

struct PyramidParams
{
  // shall input image be upscaled ( > 0)
  int upscaleInputImage;
  // number of scale per octave
  int  numberOfScales;
  // amount of smoothing applied to the initial level of first octave
  float initialSigma;
  // noise dependent threshold on the response (sensitivity)
  float threshold;
  float rel_threshold;
  int reg_number;
  float rel_reg_number;
  // ratio of the eigenvalues
  double edgeEigenValueRatio;
  // number of pixels ignored at the border of image
  int  border;
  int   doOnWLD; // detect Hessian points on WLD-transformed image
  int   doOnNormal; // detect Hessian points on normal image
  WLDParams WLDPar; //Parameters for WLD-transformation
  detection_mode_t DetectorMode;
  detector_type DetectorType;

  PyramidParams()
  {
    upscaleInputImage = 0;
    numberOfScales = 3;
    initialSigma = 1.6f;
    threshold = 16.0f/2.0f; //0.04f * 256 / 3;
    edgeEigenValueRatio = 10.0f;
    border = 5;
    doOnWLD = 0;
    doOnNormal = 1;
    DetectorMode = FIXED_TH;
    rel_threshold = -1;
    reg_number = -1;
    rel_reg_number = -1;
    DetectorType = HESSIAN_DET;
  }
};

class KeypointCallback
{
public:
  virtual void onKeypointDetected(const Mat &blur, float x, float y, float s, float pixelDistance, int type, float response) = 0;
};

struct ScaleSpaceDetector
{
  enum
  {
    HESSIAN_DARK   = 0,
    HESSIAN_BRIGHT = 1,
    HESSIAN_SADDLE = 2,
    DOG_DARK   = 10,
    DOG_BRIGHT = 11,
    HARRIS_DARK   = 30,
    HARRIS_BRIGHT = 31
  };
public:
  KeypointCallback *keypointCallback;
  PyramidParams Pyrpar;
  ScaleSpaceDetector(const PyramidParams &Pyrpar) :
    edgeScoreThreshold((Pyrpar.edgeEigenValueRatio + 1.0f)*(Pyrpar.edgeEigenValueRatio + 1.0f)/Pyrpar.edgeEigenValueRatio),
    finalThreshold(Pyrpar.threshold),
    positiveThreshold(0.8 * finalThreshold),
    negativeThreshold(-positiveThreshold)
  {
    extrema_points = 0;
    localized_points = 0;
    this->Pyrpar = Pyrpar;
    if (Pyrpar.DetectorType == HESSIAN_DET)
      finalThreshold = Pyrpar.threshold*Pyrpar.threshold;

    if (Pyrpar.DetectorMode !=FIXED_TH)
      finalThreshold = positiveThreshold = negativeThreshold = effectiveThreshold = 0.0;
    else effectiveThreshold = Pyrpar.threshold;

    if (Pyrpar.DetectorType == HESSIAN_DET)
      effectiveThreshold = effectiveThreshold*effectiveThreshold;

    keypointCallback = 0;
  }
  void setKeypointCallback(KeypointCallback *callback)
  {
    keypointCallback = callback;
  }
  void detectPyramidKeypoints(const Mat &image);
  int extrema_points;
  int localized_points;
  float effectiveThreshold;

protected:
  void detectOctaveKeypoints(const Mat &firstLevel, float pixelDistance, Mat &nextOctaveFirstLevel);
  void localizeKeypoint(int r, int c, float curScale, float pixelDistance);
  void findLevelKeypoints(float curScale, float pixelDistance);
  Mat Response(const Mat &inputImage, float norm);
  Mat iidogResponse(const Mat &inputImage, float norm);
  Mat dogResponse(const Mat &inputImage, float norm);
  Mat HessianResponse(const Mat &inputImage, float norm);
  Mat HarrisResponse(const Mat &inputImage, float norm);
  const Mat* originalImg;

private:
  // some constants derived from parameters
  const double edgeScoreThreshold;
  float finalThreshold;
  float positiveThreshold;
  float negativeThreshold;

  // temporary arrays used by protected functions
  Mat octaveMap;
  Mat prevBlur, blur;
  Mat low, cur, high;
};


\
#endif // __PYRAMID_H__
