#ifndef STRUCTURES_HPP
#define STRUCTURES_HPP
#undef __STRICT_ANSI__

#include <vector>
#include <opencv2/core/core.hpp>

enum detection_mode_t {FIXED_TH, RELATIVE_TH, FIXED_REG_NUMBER, RELATIVE_REG_NUMBER, NOT_LESS_THAN_REGIONS};
enum detector_type {HESSIAN_DET, DOG_DET, HARRIS_DET};

/// Basic structures:
struct SynthImage           // SynthImage: synthesised image from unwarped one
{
  int id;                 // image identifier
  char OrigImgName[50];   // filename of original image
  double tilt;            // tilt - scale factor in vertical direction. (y_synth=y_original / tilt)
  double rotation;        // angle of rotation, befote tilting. Counterclockwise, around top-left pixel, radians
  double zoom;            // scale factor, (x_synth,y_synth) = zoom*(x,y), before tilting and rotating
  double H[3*3];          // homography matrix from original image to synthesised
  cv::Mat pixels;         // image data
};

struct AffineKeypoint
{
  double x,y;            // subpixel, image coordinates
  double a11, a12, a21, a22;  // affine shape matrix
  double s;                   // scale
  double response;
  int type;
};

struct AffineRegion
{
  int img_id;              //image id, where shape detected
  int img_reproj_id;   //original untilted image id (always =zero)
  int parent_id;           //parent region id (when detect orientation). = -1 when parent is undefined;
  int id;                  //region id
  int group_id;            //group id
  int described;            //for iterative matching
  int group_parent;

  AffineKeypoint det_kp;   //affine region in detected image
  AffineKeypoint reproj_kp;//reprojected affine region to the original image
  std::vector<float> desc;            //SIFT descriptor: array of gradient orientation histograms in a neighbors

};
typedef std::vector<AffineRegion> AffineRegionList;

struct ViewSynthParameters
{
  double zoom;
  double tilt;
  double phi; //in radians
  double InitSigma;
  int doBlur;
};

#endif // STRUCTURES_HPP
